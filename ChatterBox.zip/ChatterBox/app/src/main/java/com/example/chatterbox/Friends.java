package com.example.chatterbox;

import java.util.ArrayList;

public class Friends extends ArrayList<Friends> {

    public String phoneNo;


//    public String lastmsg;
//    public boolean IS_MSG_FROM_YOU;
//    public ArrayList<Messages> all_messages = new ArrayList<>();
//
//    public void addNewMessage(){
//         Messages new_message = new Messages(IS_MSG_FROM_YOU,lastmsg);
//         all_messages.add(new_message);
//    }


}